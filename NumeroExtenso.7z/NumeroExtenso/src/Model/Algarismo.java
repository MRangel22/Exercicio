package Model;
public class Algarismo{
	private String valExtenso;
	
	public Algarismo(String valor) {
		this.setValExtenso(valor);
	}

	public String getValExtenso() {
		return valExtenso;
	}

	public void setValExtenso(String valExtenso) {
		this.valExtenso = valExtenso;
	}
	
}
	
	 

